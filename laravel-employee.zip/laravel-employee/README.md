# Employee-Payroll-PHP-Laravel

Employee Payroll System In Laravel Framework project is a desktop application which is developed in Laravel PHP platform.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

A local server like xampp, wamp or mamp is needed in order to run this app locally. It can be hosted on web server for online use


## Built With

* PHP-Laravel, Javascript, Jquery, Ajax,bootstrap- The web programmming languages used
* HTML and CSS - Used for designing



# Employee Payroll System In Laravel Framework

# Employee-Payroll-PHP-Laravel
# Empoyee-pay-PHP-Laravel
# Empoyee-pay-PHP-Laravel
# Empoyee-pay-PHP-Laravel
# employeePayroll-PHP-Laravel
